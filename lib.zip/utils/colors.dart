import 'dart:ui';

class MyColors {

  static const Color btmGray = const Color(0xFFA2A2A2);
  static const Color green = const Color(0xFF6DC07B);
  static const Color vazn = const Color(0xFFF15A23);
  static const Color aab = const Color(0xFF24AEFC);
  static const Color ghaza = const Color(0xFFFF3939);
  static const Color varzesh = const Color(0xFFFFEB3B);
  static const Color border = const Color(0xFFD5D5D5);





}