// import 'dart:convert';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_spinkit/flutter_spinkit.dart';
// import 'package:http/http.dart' show get;
//
// import '../helper.dart';
//
// class fruitUnit extends StatefulWidget {
//   State<StatefulWidget> createState() => fruitUnitState();
//
//   fruitUnit({Key key}) : super(key: key);
// }
//
// class fruitUnitState extends State<fruitUnit> {
//   List<fruits> _allFruit = [];
//   @override
//   void initState() {
//    _updateAllfruits();
//     super.initState();
//   }
//   final _scaffoldKey = GlobalKey<ScaffoldState>();
//   bool _isLoading=true;
//   bool _isLoadingUpdate=false;
//   var fontvar=1.0;
//   @override
//   Widget build(BuildContext context) {
//     SizeConfig().init(context);
//     var bh=SizeConfig.safeBlockHorizontal;
//     var bv=SizeConfig.safeBlockVertical;
//     fontvar = (bh) / 3.75;
//     if(fontvar>2)fontvar=1.7;
//
//     Size screenSize = MediaQuery.of(context).size;
//     if(screenSize.width>600)screenSize=Size(600, screenSize.height);
//
//     return Scaffold(
//       key: _scaffoldKey,
//       appBar: AppBar(
//         backgroundColor: MyColors.green,
//         automaticallyImplyLeading: false,
//         centerTitle: true,
//         actions: <Widget>[
//       Padding(padding: EdgeInsets.all(5),child:     IconButton(
//             icon: Icon(
//               Icons.chevron_right,
//               size:  32*(screenSize.width)/375,
//               textDirection: TextDirection.rtl,
//             ),
//             onPressed: () {
//               Navigator.pop(context);
//             },
//
//             color: Colors.white,
//             splashColor: Colors.amber,
//             padding: EdgeInsets.all(7),
//       )),
//         ],
//         title: Text("اندازه واحد هر کدام از میوه ها ",style: TextStyle(
//           color: Colors.white,
//           fontSize:14*fontvar ,
//           fontWeight:FontWeight.w700
//         ),),
//       ),
//
//         body:
//
//         _isLoading
//             ? LoadingW()
//             :   new ListView.builder(
//                     itemCount:_allFruit.length+1,
//                     padding: EdgeInsets.symmetric(vertical: 10,horizontal: 10),
//                     itemBuilder: (context, index) {
//                       if(index==0)
//                         return Column(
//                           children: <Widget>[
//                             Container(
//                               margin: EdgeInsets.symmetric(
//                                   vertical: 15, horizontal: 15),
//                               child: TextField(
//                                 keyboardType: TextInputType.text,
//                                 style: TextStyle(
//                                     color: Color(0xff5c5c5c),
//                                     fontSize: 14 * fontvar,
//                                     fontWeight: FontWeight.w500),
//                                 decoration: new InputDecoration(
//                                     focusColor: Colors.white,
//                                     fillColor: Colors.white,
//
//                                     suffixIcon: Padding(
//                                       padding: EdgeInsets.all(0), child: Icon(
//                                       Icons.search,
//                                       color: Color(0xffA2A2A2),
//                                     ),),
//
//                                     border: new OutlineInputBorder(
//                                         borderSide: new BorderSide(
//                                             color: MyColors.border, width: 1),
//                                         borderRadius:
//                                         BorderRadius.all(Radius.circular(10))),
//                                     enabledBorder: new OutlineInputBorder(
//                                         borderSide: new BorderSide(
//                                             color: MyColors.border, width: 1),
//                                         borderRadius:
//                                         BorderRadius.all(Radius.circular(10))),
//                                     focusedBorder: new OutlineInputBorder(
//                                         borderSide: new BorderSide(
//                                             color: MyColors.green, width: 1),
//                                         borderRadius:
//                                         BorderRadius.all(Radius.circular(10))),
//                                     hintText: 'جستجو',
//                                     hintStyle: TextStyle(
//                                         color: Colors.black26,
//                                         fontSize: 14 * fontvar,
//                                         fontWeight: FontWeight.w400),
//                                     contentPadding: const EdgeInsets.only(
//                                         top: 5, right: 5, bottom: 0, left: 5)),
//                                 onChanged: (String value) async {
//                                   if (value.contains(
//                                       String.fromCharCode(1610))) {
//                                     int index = value.indexOf(String
//                                         .fromCharCode(1610));
//                                     print(index.toString());
//                                     value = value.replaceRange(
//                                         index, index + 1, String.fromCharCode(
//                                         1740));
//                                   }
//
//                                   if (value.contains(
//                                       String.fromCharCode(1603))) {
//                                     int index = value.indexOf(String
//                                         .fromCharCode(1603));
//                                     print(index.toString() + "سسب");
//                                     value = value.replaceRange(
//                                         index, index + 1, String.fromCharCode(
//                                         1705));
//                                   }
//
//                                   await fruitSearch(value);
//                                 },
//
//
//                               ),
//                             ),
//                             (dateCall.getUpdate()!=null&&dateCall.getUpdate()!="finish")
//                                 ? Row(
//                               mainAxisAlignment: MainAxisAlignment.center,
//                               children: <Widget>[
//                                 SpinKitCircle(
//                                   color: MyColors.vazn,
//                                   size: 35,
//                                 ),
//                                 Text("در حال دریافت تصاویر",
//                                   style: TextStyle(
//                                       color: Colors.black,
//                                       fontSize: 12*fontvar,
//                                       fontWeight: FontWeight.w400
//                                   ),)
//                               ],
//                             )
//                                 :Container()
//                           ],
//                         );
//                       else
//                         return listItem(index-1);}));
//   }
//   getallFruit() async {
//     List<fruits>  list=[];
//     try {
//       var db = new fruitsProvider();
//       await db.open();
//        list= await db.paginate();
// //      await db.close();
//     } catch (e) {
//       print(e.toString());
//     }
//
//     if(mounted)   setState(() {
//     _allFruit=list;
//       _isLoading=false;
//     });
//
//   }
//   Future<bool> _updateAllfruits() async {
//     List<fruits> products=[];
//     try {
//       var db = new fruitsProvider();
//       await db.open();
//       products= await db.paginate();
// //      await db.close();
//     } catch (e) {
//       print(e.toString());
//     }
//
//
//     print("elseeeeinjaa");
//     if(mounted)  setState(() {
//       _allFruit=products;
//       _isLoading=false;
//     });
//
//     if(dateCall.getUpdate()==null){
//     if(products.length>0&& products[0].cover.contains("https://api.barikaapp.com")) {
//       if (await checkConnectionInternet()) {
//         dateCall.saveUpdate("yes");
//         for (int i = 0; i < products.length; i++) {
//           print(products[i].cover);
//           print(products[i].id);
//           if (products[i].cover.contains("https://api.barikaapp.com")) {
//             var response = await get(products[i].cover);
//             String imgString = Utility.base64String(response.bodyBytes);
//             products[i].cover = imgString;
//           }
//         }
//
//
//         try {
//           var db = new fruitsProvider();
//           await db.open();
//           await db.updateAll(products);
// //          await db.close();
//           dateCall.saveUpdate("finish");
//         } catch (e) {
//         }}}}}
// //  Future<bool> _updateAllfruits() async {
// //    List<fruits> products=[];
// //    try {
// //      var db = new fruitsProvider();
// //      await db.open();
// //      products= await db.paginate();
// //      await db.close();
// //    } catch (e) {
// //      print(e.toString());
// //    }
// //
// //
// //    print("elseeeeinjaa");
// //    if(mounted)  setState(() {
// //      _allFruit=products;
// //      _isLoading=false;
// //    });
// //    print(products[0].cover);
// //    if(products.length>0&& products[0].cover.contains("http://api.barikaapp.com")) {
// //      if (await checkConnectionInternet()) {
// //        for (int i = 0; i < products.length; i++) {
// //          print(products[i].cover);
// //          print(products[i].id);
// //          if (products[i].cover.contains("http://api.barikaapp.com")) {
// //            var response = await get(products[i].cover);
// //            String imgString = Utility.base64String(response.bodyBytes);
// //            products[i].cover = imgString;
// //            try {
// //              var db = new fruitsProvider();
// //              await db.open();
// //              await db.updateone( products[i]);
// //              await db.close();
// //            } catch (e) {
// //            }
// ////
// //          }
// //
// //
// //        }
// //
// //
// ////        try {
// ////          var db = new fruitsProvider();
// ////          await db.open();
// ////          await db.updateAll(products);
// ////          await db.close();
// ////        } catch (e) {
// ////        }
// //      }}}
//   fruitSearch(String value) async {
//     List<fruits> products3 =[];
//     try {
//       var db = new fruitsProvider();
//       await db.open();
//       products3= await db.searchfood(value);
// //      await db.close();
//       if(mounted)   setState(() {
//         _allFruit =products3;
//       });
//
//     }
//     catch(e){
//       print("sabziiiiiiii"+e.toString());
//     }
//
//
//
//
//   }
//
//   Widget listItem(int i) {
//
//
//
//     Size screenSize = MediaQuery.of(context).size;
//     if(screenSize.width>600)screenSize=Size(600, screenSize.height);
//
//     return Card(
//       elevation: 8,
//       margin:EdgeInsets.only(top:16) ,
//       shape: RoundedRectangleBorder(
//         borderRadius: BorderRadius.circular(10.0),
//       ),
//       child:Padding(padding: EdgeInsets.symmetric(vertical: 15,horizontal: 10),child:  Row(
//         mainAxisAlignment: MainAxisAlignment.start,
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: <Widget>[
//        Padding(padding: EdgeInsets.only(left: 8),
//        child:  _allFruit[i].cover.contains("https://api.barikaapp.com")
//            ?ClipRRect(
//            borderRadius: BorderRadius.circular(10.0),
//            child:Image.asset('assets/images/placeholder.png',
//              fit: BoxFit.cover,
//             width:85*(screenSize.width-20)/355,
//             height:(95)*(screenSize.width-20)/355 ,))
//            :    Image.memory(
//          base64Decode(_allFruit[i].cover),
//          fit: BoxFit.contain,
//          width:85*(screenSize.width-20)/355,
//          height:(95)*(screenSize.width-20)/355 ,
//        ),
//        ),
//           Expanded(child: Column(
//             mainAxisAlignment: MainAxisAlignment.start,
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: <Widget>[
//               Text(_allFruit[i].name,
//                 style: TextStyle(
//                     color: Colors.black,
//                     fontSize: 19*fontvar,
//                     fontWeight: FontWeight.w500
//                 ),),
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.start,
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: <Widget>[
//                   Flexible(child:  Text("اندازه یک واحد:",
//                     style: TextStyle(
//                         color: Colors.black,
//                         fontSize: 16*fontvar,
//                         fontWeight: FontWeight.w400
//                     ),)),
//                   Flexible(child: Text(_allFruit[i].size,
//                     style: TextStyle(
//                         color: MyColors.green,
//                         fontSize: 16*fontvar,
//                         fontWeight: FontWeight.w400
//                     )),),
//                 ],
//               ),
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.start,
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: <Widget>[
//                   Flexible(child:     Text("وزن یک واحد:",
//                     style: TextStyle(
//                         color: Colors.black,
//                         fontSize: 16*fontvar,
//                         fontWeight: FontWeight.w400
//                     ),)),
//               Flexible(child:  Text(_allFruit[i].weight +" گرم",
//                     style: TextStyle(
//                         color: MyColors.green,
//                         fontSize: 16*fontvar,
//                         fontWeight: FontWeight.w400
//                     ),)),
//                 ],
//               ),
//             ],
//           ))
//         ],
//       ),)
//     );
//
//
//   }
//
//   LoadingW() {
//
//     return  Center(
//     child: SpinKitCircle(
//     color: MyColors.vazn,
//     ));
//
//   }
// //  LoadingUpdate() {
// //
// //    return  Center(
// //    child: Column(
// //      mainAxisAlignment: MainAxisAlignment.center,
// //      crossAxisAlignment: CrossAxisAlignment.center,
// //      children: <Widget>[
// //    SpinKitCircle(
// //    color: MyColors.vazn,
// //    ),Padding(
// //          padding: EdgeInsets.symmetric(vertical: 10),
// //          child: Text("درحال دریافت اطلاعات.لطفا منتظر بمانید." , style: TextStyle(
// //              color: Colors.black,
// //              fontSize: 13*fontvar,
// //              fontWeight: FontWeight.w400
// //          ),),
// //        )
// //
// //      ],
// //    ));
// //
// //  }
//   showSnakBar(String name)  {
//
//     _scaffoldKey.currentState.showSnackBar(
//         new SnackBar(
//           duration: new Duration(seconds: 5),
//           backgroundColor: MyColors.vazn,
//           behavior: SnackBarBehavior.floating,
//           shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.all(Radius.circular(20))),
//
//           content: Text(
//             name,
//             style: TextStyle(fontWeight: FontWeight.w400,fontSize: 15*fontvar,fontFamily: "iransansDN"),textDirection: TextDirection.rtl,),
//         ));
//
//   }
//
// }