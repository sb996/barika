import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:barika_web/exercise/Exercise.dart';
import 'package:barika_web/models/contact.dart';
import 'package:barika_web/models/user.dart';
import 'package:barika_web/mokamel/mokamel.dart';
import 'package:barika_web/regimiFood/regimiFoodList.dart';
import 'package:barika_web/services/apiServices.dart';
import 'package:barika_web/store/storeScreen.dart';
import 'package:barika_web/utils/SizeConfig.dart';
import 'package:barika_web/utils/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:persian_datepicker/persian_datetime.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:path/path.dart' as Path;
import 'package:tutorial_coach_mark/animated_focus_light.dart';
import 'package:tutorial_coach_mark/content_target.dart';
import 'package:tutorial_coach_mark/target_focus.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';
import 'package:url_launcher/url_launcher.dart';
import '../helper.dart';
import 'PeymentHistory.dart';

import 'connectus.dart';
import 'reminder.dart';

class menuScreen extends StatefulWidget {
  @override
  final contextt;

  menuScreen({Key key, this.contextt}) : super(key: key);

  State<StatefulWidget> createState() => menuScreenState();
}

class menuScreenState extends State<menuScreen>
    with AutomaticKeepAliveClientMixin<menuScreen> {
  @override
  bool get wantKeepAlive => true;
  User _user;
  String date = "";
  bool com = true;
  Color textColor = Color(0xff5C5C5C);
  List<TargetFocus> targets = List();
  GlobalKey keyButton1 = GlobalKey();
  GlobalKey keyButton2 = GlobalKey();
  bool _isLoading = false;
  String _version="";
  String telegram="";
  String rubika="";
  String _country="";
  String instagram="";
  String website="";
  String description="";
  int etebar=1;
  Widget loadingView() {
    return Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          elevation: 0,
          title: Text(
            "منو",
            style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w500,
                fontSize: 20 * fontvar),
          ),
          centerTitle: true,
        ),
        body: Center(
            child:SpinKitCircle(
              color: MyColors.vazn,
            )
        ));
  }
  @override
  void initState() {

    // _getUser();
    // initTargets();
    // WidgetsBinding.instance.addPostFrameCallback(_afterLayout);
    setData();
    super.initState();
  }

  var fontvar = 1.0;
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    var bh = SizeConfig.safeBlockHorizontal;
    var bv = SizeConfig.safeBlockVertical;
    fontvar = (bh) / 3.75;
    if (fontvar > 2) fontvar = 1.7;

    Size screenSize = MediaQuery
        .of(context)
        .size;
    if (screenSize.width > 600) screenSize = Size(600, screenSize.height);

    return Container(
      width: screenSize.width - 50,
      color: Colors.white,
      child: _isLoading
          ? loadingView()
          : Drawer(
          child: Scaffold(
            key: _scaffoldKey,
            appBar: PreferredSize(
              child: Container(
                color: Colors.green,
              ),
              preferredSize: Size.fromHeight(0),

            ),
            body: ListView(
              children: <Widget>[


                Container(
                    // height: (((screenSize.width * 180) / 375)),
                    color: MyColors.green,
                    padding: EdgeInsets.only(right: 10,top: 20,bottom:25 ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          _user != null ? _user.name : "",
                          style: TextStyle(
                              color: Colors.white, fontSize: 14 * fontvar),
                        ),
                        Text(
                          _user != null ? _country+_user.phone+"+" : "",
                          style: TextStyle(
                              color: Colors.white, fontSize: 14 * fontvar),
                        ),

                        Container(
                          width:MediaQuery.of(context).size.width ,
                          height: 1,
                          color:Color(0xffE8FFDD).withOpacity(0.3) ,
                          margin: EdgeInsets.only(top: 5,bottom: 5,left:20 ,right:10 ),
                        ),
                        Container(
                          child:
                          //   (_user.account == null || _user.account == "" || etebar<0)
                        //   ?Row(
                        //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        //   children: [
                        //     Row(
                        //       mainAxisAlignment: MainAxisAlignment.start,
                        //       crossAxisAlignment: CrossAxisAlignment.start,
                        //       children: [
                        //         Container(
                        //           margin: EdgeInsets.only(left: 5),
                        //           child: Image.network(
                        //             'assets/icons/supermarket.svg',
                        //             width: 27 * (screenSize.width) / 375,
                        //             height: 24 * (screenSize.width) / 375,
                        //           ),
                        //         ),
                        //         Column(
                        //          mainAxisAlignment: MainAxisAlignment.start,
                        //          crossAxisAlignment: CrossAxisAlignment.start,
                        //          children: [
                        //            Text(
                        //              "فروشگاه",
                        //              style: TextStyle(
                        //                  color: Colors.white, fontSize: 15 * fontvar,fontWeight: FontWeight.w500),
                        //            ),
                        //            Text(
                        //              "شما اشتراک فعالی ندراید",
                        //              style: TextStyle(
                        //                  color: Colors.white, fontSize: 12 * fontvar,fontWeight: FontWeight.w400),
                        //            ),
                        //          ],
                        //        ),
                        //       ],
                        //     ),
                        //     FlatButton(
                        //
                        //       child:Text(
                        //         "خرید اشتراک",
                        //         style: TextStyle(
                        //             color: Colors.white,
                        //             fontWeight: FontWeight.w500,
                        //             fontSize: 13*fontvar
                        //         ),
                        //         textAlign: TextAlign.center,
                        //         textDirection: TextDirection.ltr,
                        //       ) ,
                        //       materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        //       onPressed: () async {
                        //           User user =await Navigator.push(
                        //             context,
                        //             MaterialPageRoute(
                        //                 builder: (context) =>
                        //                     Directionality(
                        //                         textDirection: TextDirection.rtl,
                        //                         child: storeScreen(menu: true,user: _user,))),
                        //           );
                        //
                        //           setState(() {
                        //             print("menuuuuuuuuesr");
                        //             print(user.toMap());
                        //             user.name="54";
                        //             user.name="54";
                        //             _user=user;
                        //           });
                        //
                        //         },
                        //       color:Color(0xffF15A23) ,
                        //       padding: EdgeInsets.symmetric(horizontal:0,vertical: 0),
                        //       shape:  RoundedRectangleBorder(borderRadius:  BorderRadius.circular(4.0)),
                        //     )
                        //
                        //   ],
                        // )
                        //   :
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(left: 5),
                                    child: Image.network(
                                      'assets/icons/accept.svg',
                                      fit: BoxFit.fill,
                                      width: 27 * (screenSize.width) / 375,
                                      height: 24 * (screenSize.width) / 375,
                                    ),
                                  ),

                                  Text(
                                    "تاریخ اعتبار اشتراک",
                                    style: TextStyle(
                                        color: Colors.white, fontSize: 15 * fontvar,fontWeight: FontWeight.w500),
                                  ),

                                ],
                              ),

                              Text(
                                // _user.account??
                                    "_user.account",
                                style: TextStyle(
                                    color: Colors.white, fontSize: 18 * fontvar,fontWeight: FontWeight.w500),
                              ),
                            ],
                          ),
                            margin:  EdgeInsets.only(left: 10,top: 15),
                ),
                        // Container(
                        //   margin: EdgeInsets.symmetric(vertical: 5),
                        //   padding:
                        //   EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                        //   decoration: BoxDecoration(
                        //       color: Colors.white,
                        //       borderRadius:
                        //       BorderRadius.all(Radius.circular(10))),
                        //   child: Text(
                        //
                        //     (_user.account == null || _user.account == "")
                        //         ?  "تاریخ اعتبار اشتراک : " +"اشتراک فعالی ندارید."
                        //         : "تاریخ اعتبار اشتراک : " + _user.account.toString(),
                        //     style: TextStyle(
                        //         color: Colors.black,
                        //         fontSize: 12 * fontvar),
                        //   ),
                        // ),

                      ],
                    )),

                Padding(
                    padding: EdgeInsets.symmetric( vertical: 5),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      GestureDetector(
                        child: Container(
                          margin: EdgeInsets.symmetric(horizontal: 5),
                          child: Image.network(
                            'assets/icons/instagram.svg',
                            fit: BoxFit.fill,
                            width: 35 * (screenSize.width) / 375,
                            height: 35 * (screenSize.width) / 375,
                          ),
                        ),
                        onTap: () async {
                          await openApp(instagram);
                        },
                      ),
                      GestureDetector(
                        // child: Container(
                        //   margin: EdgeInsets.symmetric(horizontal: 5),
                        child: Image.asset(
                          'assets/images/wh.png',
                          width: 45 * (screenSize.width) / 375,
                          height: 45 * (screenSize.width) / 375,
                        ),
                        // ),
                        onTap: () async {
                          await openApp(rubika);
                        },
                      ),
                      GestureDetector(
                        child: Container(
                          margin: EdgeInsets.symmetric(horizontal: 5),
                          child: Image.network(
                            'assets/icons/telegram.svg',
                            fit: BoxFit.fill,
                            width: 35 * (screenSize.width) / 375,
                            height: 35 * (screenSize.width) / 375,
                          ),
                        ),
                        onTap: () async {
                          await  openApp(telegram);
                        },
                      ),
                      GestureDetector(
                        child: Container(
                          margin: EdgeInsets.symmetric(horizontal: 5),
                          child: Image.network(
                            'assets/icons/site.svg',
                            fit: BoxFit.fill,
                            width: 35 * (screenSize.width) / 375,
                            height: 35 * (screenSize.width) / 375,
                          ),
                        ),
                        onTap: () async {
                          await   openApp(website);
                        },
                      ),

                    ],
                  ),
                ),

                ListTile(
                  key: keyButton1,
                  onTap: () {
                  //   if(_user != null){
                  //     if ( calculateAge(_user.birthdate) < 3)
                  //       showSnakBar(
                  //           "برای زیر سه سال غیر فعال است.");
                  //     else {
                  //       Navigator.push(
                  //         context,
                  //         MaterialPageRoute(
                  //             builder: (context) =>
                  //                 Directionality(
                  //                     textDirection: TextDirection.rtl,
                  //                     child: goalWeight(
                  //                       acountDate: _user.account,
                  //                     ))),
                  //       );
                  //     }}
                  },
                  title: Text(
                    'تعیین  هدف ',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w400,
                        fontSize: 15 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                  contentPadding:   EdgeInsets.all(0),
                  leading:   Padding(
                    padding:
                    EdgeInsets.only(
                        right: 15, top: 15,bottom: 15),
                    child:  Image.network(
                      'assets/icons/menu_goal.svg', fit: BoxFit.fill,
                      width: 20 * (screenSize.width) / 375,
                      height: 20 * (screenSize.width) / 375,
                    ),
                  ) ,
                ),
                ListTile(

                  onTap: () {
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //       builder: (context) =>
                    //           Directionality(
                    //               textDirection: TextDirection.rtl,
                    //               child: dailyInfo())),
                    // );
                  },
                  title: Text(
                    'گزارش روزانه',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w400,
                        fontSize: 15 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                  contentPadding:   EdgeInsets.all(0),
                  leading:   Padding(
                    padding:
                    EdgeInsets.only(
                        right: 15, top: 15,bottom: 15),
                    child:  Image.network(
                      'assets/icons/menu_report.svg', fit: BoxFit.fill,
                      width: 20 * (screenSize.width) / 375,
                      height: 20 * (screenSize.width) / 375,
                    ),
                  ) ,
                ),
                ListTile(

                  onTap: () {
                  //   Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //         builder: (context) =>
                  //             Directionality(
                  //                 textDirection: TextDirection.rtl,
                  //                 child: regimList())),
                  //   );
                  },
                  title: Text(
                    'رژیم های غذایی من',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w400,
                        fontSize: 15 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                  contentPadding:   EdgeInsets.all(0),
                  leading:   Padding(
                    padding:
                    EdgeInsets.only(
                        right: 15, top: 15,bottom: 15),
                    child:  Image.network(
                      'assets/icons/menu_regims.svg', fit: BoxFit.fill,
                      width: 20 * (screenSize.width) / 375,
                      height: 20 * (screenSize.width) / 375,
                    ),
                  ) ,
                ),
                ListTile(
                  key: keyButton2,
                  onTap: () {
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //       builder: (context) =>
                    //           Directionality(
                    //               textDirection: TextDirection.rtl,
                    //               child: unitConvert())),
                    // );
                  },
                  title: Text(
                    'تبدیل واحد مواد نشاسته ای به یکدیگر',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w400,
                        fontSize: 15 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                  contentPadding:   EdgeInsets.all(0),
                  leading:   Padding(
                    padding:
                    EdgeInsets.only(
                        right: 15, top: 15,bottom: 15),
                    child:  Image.network(
                      'assets/icons/menu_reminder.svg', fit: BoxFit.fill,
                      width: 20 * (screenSize.width) / 375,
                      height: 20 * (screenSize.width) / 375,
                    ),
                  ) ,
                ),
                ListTile(
                  onTap: () {
                  //   Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //         builder: (context) =>
                  //             Directionality(
                  //                 textDirection: TextDirection.rtl,
                  //                 child: fruitUnit())),
                  //   );
                  },
                  title: Text(
                    'اندازه واحد هر کدام از میوه ها ',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w400,
                        fontSize: 15 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                  contentPadding:   EdgeInsets.all(0),
                  leading:   Padding(
                    padding:
                    EdgeInsets.only(
                        right: 15, top: 15,bottom: 15),
                    child:  Image.network(
                      'assets/icons/menu_reminder.svg', fit: BoxFit.fill,
                      width: 20 * (screenSize.width) / 375,
                      height: 20 * (screenSize.width) / 375,
                    ),
                  ) ,
                ),
                ListTile(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              Directionality(
                                  textDirection: TextDirection.rtl,
                                  child: mokamel(
                                    // acountDate: _user.account,
                                    acountDate: "1398/02/02",
                                  ))),
                    );
                  },
                  title: Text(
                    ' مکمل های غذایی ',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w400,
                        fontSize: 15 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                  contentPadding:   EdgeInsets.all(0),
                  leading:   Padding(
                    padding:
                    EdgeInsets.only(
                        right: 15, top: 15,bottom: 15),
                    child:  Image.network(
                      'assets/icons/menu_mokamel.svg', fit: BoxFit.fill,
                      width: 20 * (screenSize.width) / 375,
                      height: 20 * (screenSize.width) / 375,
                    ),
                  ) ,
                ),
                ListTile(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              Directionality(
                                  textDirection: TextDirection.rtl,
                                  child: ExerciseScreen(
                                    // acountDate: _user.account,
                                    acountDate: "1398/02/02",
                                  ))),
                    );
                  },
                  title: Text(
                    'ورزشها و حرکات ورزشی ',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w400,
                        fontSize: 15 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                  contentPadding:   EdgeInsets.all(0),
                  leading:   Padding(
                    padding:
                    EdgeInsets.only(
                        right: 15, top: 15,bottom: 15),
                    child:  Image.network(
                      'assets/icons/menu_sport.svg', fit: BoxFit.fill,
                      width: 20 * (screenSize.width) / 375,
                      height: 20 * (screenSize.width) / 375,
                    ),
                  ) ,
                ),
                ListTile(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              Directionality(
                                  textDirection: TextDirection.rtl,
                                  child: regimiFoodList(
                                    // acountDate: _user.account,
                                    acountDate: "1398/02/02",
                                  ))),
                    );
                  },
                  title: Text(
                    'دستور پخت غذاهای رژیمی',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w400,
                        fontSize: 15 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                  contentPadding:   EdgeInsets.all(0),
                  leading:   Padding(
                    padding:
                    EdgeInsets.only(
                        right: 15, top: 15,bottom: 15),
                    child:  Image.network(
                      'assets/icons/menu_foods.svg', fit: BoxFit.fill,
                      width: 20 * (screenSize.width) / 375,
                      height: 20 * (screenSize.width) / 375,
                    ),
                  ) ,
                ),
                ListTile(
                  onTap: () {
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //       builder: (context) =>
                    //           Directionality(
                    //               textDirection: TextDirection.rtl,
                    //               child: chart())),
                    // );
                  },
                  title: Text(
                    ' نمودارها ',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w400,
                        fontSize: 15 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                  contentPadding:   EdgeInsets.all(0),
                  leading:   Padding(
                    padding:
                    EdgeInsets.only(
                        right: 15, top: 15,bottom: 15),
                    child:  Image.network(
                      'assets/icons/menu_chart.svg', fit: BoxFit.fill,
                      width: 20 * (screenSize.width) / 375,
                      height: 20 * (screenSize.width) / 375,
                    ),
                  ) ,
                ),
                ListTile(
                  onTap: () {
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //       builder: (context) =>
                    //           Directionality(
                    //               textDirection: TextDirection.rtl,
                    //               child: reportCahrt()
                    //             // child: LineChartSample6()
                    //
                    //
                    //           )),
                    // );
                  },
                  title: Text(
                    ' گزارش گیری ',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w400,
                        fontSize: 15 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                  contentPadding:   EdgeInsets.all(0),
                  leading:   Padding(
                    padding:
                    EdgeInsets.only(
                        right: 15, top: 15,bottom: 15),
                    child:  Image.network(
                      'assets/icons/menu_chart.svg', fit: BoxFit.fill,
                      width: 20 * (screenSize.width) / 375,
                      height: 20 * (screenSize.width) / 375,
                    ),
                  ) ,
                ),
                ListTile(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              Directionality(
                                  textDirection: TextDirection.rtl,
                                  child: PeymentHistory())),
                    );
                  },
                  title: Text(
                    'لیست تراکنش ها',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w400,
                        fontSize: 15 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                  contentPadding:   EdgeInsets.all(0),
                  leading:   Padding(
                    padding:
                    EdgeInsets.only(
                        right: 15, top: 15,bottom: 15),
                    child:  Image.network(
                      'assets/icons/menu_report.svg', fit: BoxFit.fill,
                      width: 20 * (screenSize.width) / 375,
                      height: 20 * (screenSize.width) / 375,
                    ),
                  ) ,
                ),
                ListTile(
                  onTap: () {
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //       builder: (context) =>
                    //           Directionality(
                    //               textDirection: TextDirection.rtl,
                    //               child: questionScreen())),
                    // );
                  },
                  title: Text(
                    'سولات متداول ',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w400,
                        fontSize: 15 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                  contentPadding:   EdgeInsets.all(0),
                  leading:   Padding(
                    padding:
                    EdgeInsets.only(
                        right: 15, top: 15,bottom: 15),
                    child:  Image.network(
                      'assets/icons/menu_question.svg', fit: BoxFit.fill,
                      width: 20 * (screenSize.width) / 375,
                      height: 20 * (screenSize.width) / 375,
                    ),
                  ) ,
                ),
                ListTile(
                  onTap: () {
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //       builder: (context) =>
                    //           Directionality(
                    //               textDirection: TextDirection.rtl,
                    //               child: inviteFriends())),
                    // );
                  },
                  title: Text(
                    'دعوت از دوستان',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w400,
                        fontSize: 15 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                  contentPadding:   EdgeInsets.all(0),
                  leading:   Padding(
                    padding:
                    EdgeInsets.only(
                        right: 15, top: 15,bottom: 15),
                    child:  Image.network(
                      'assets/icons/share.svg', fit: BoxFit.fill,
                      width: 20 * (screenSize.width) / 375,
                      height: 20 * (screenSize.width) / 375,
                    ),
                  ) ,
                ),
                ListTile(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              Directionality(
                                  textDirection: TextDirection.rtl,
                                  child: connectUs())),
                    );
                  },
                  title: Text(
                    'ارتباط با ما',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w400,
                        fontSize: 15 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                  contentPadding:   EdgeInsets.all(0),
                  leading:   Padding(
                    padding:
                    EdgeInsets.only(
                        right: 15, top: 15,bottom: 15),
                    child:  Image.network(
                      'assets/icons/contactus.svg', fit: BoxFit.fill,
                      width: 20 * (screenSize.width) / 375,
                      height: 20 * (screenSize.width) / 375,
                    ),
                  ) ,
                ),


                Padding(
                  padding: EdgeInsets.only(right: 18),
                  child: Text(
                    'تنظیمات',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w700,
                        fontSize: 16 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                ),

                ListTile(
                  onTap: () async {
                    // User user =await Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //       builder: (context) =>
                    //           Directionality(
                    //               textDirection: TextDirection.rtl,
                    //               child: profileScreen(menu: true,))),
                    // );

                    // setState(() {
                    //   _user=user;
                    // });

                  },
                  title: Text(
                    'پروفایل',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w400,
                        fontSize: 15 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                  contentPadding:   EdgeInsets.all(0),
                  leading:   Padding(
                    padding:
                    EdgeInsets.only(
                        right: 15, top: 15,bottom: 15),
                    child:  Image.network(
                      'assets/icons/menu_user.svg', fit: BoxFit.fill,
                      width: 20 * (screenSize.width) / 375,
                      height: 20 * (screenSize.width) / 375,
                    ),
                  ) ,
                ),
                ListTile(
                  onTap: () async {
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //       builder: (context) =>
                    //           Directionality(
                    //               textDirection: TextDirection.rtl,
                    //               child: reminder())),
                    // );
                  },
                  title: Text(
                    'یادآور',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w400,
                        fontSize: 15 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                  contentPadding:   EdgeInsets.all(0),
                  leading:   Padding(
                    padding:
                    EdgeInsets.only(
                        right: 15, top: 15,bottom: 15),
                    child:  Image.network(
                      'assets/icons/menu_reminder.svg', fit: BoxFit.fill,
                      width: 20 * (screenSize.width) / 375,
                      height: 20 * (screenSize.width) / 375,
                    ),
                  ) ,
                ),
                ListTile(
                  onTap: () async {
//                     String returnVal = await showDialog(
//                         context: context,
//                         builder: (BuildContext context) {
//                           return Padding(
//                               padding: EdgeInsets.all(0),
//                               child: Dialog(
//                                   elevation: 15,
//                                   shape: RoundedRectangleBorder(
//                                     borderRadius: BorderRadius.circular(10),
//                                   ),
//                                   backgroundColor: Colors.transparent,
//                                   child: exitDialog()));
//                         });
//                     if (returnVal == 'yes') {
// //                        Database db;
// //                        String _path;
// //                        var databasesPath = await getDatabasesPath();
// //                        _path = Path.join(databasesPath, 'king.db');
// //                        if (await databaseExists(_path)) {
// //                          await deleteDatabase(_path);
// //                          print("deleteDatabase");
// //                        }
//                       try{
//                         String phoneSave;
//                         if(_user!=null)
//                           phoneSave=_user.phone;
//                         else{
//                           User user=await getUsersq();
//                           phoneSave=user.phone;
//                         }
//                         if(phoneSave!=null){
//
//                           await deleteUser();
//
//                           await deleteDailyDiet();
//
//                           SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
//                           String date=await sharedPreferences.getString("apiDate");
//
//                           await sharedPreferences.clear();
//
//                           await sharedPreferences.setString('user_phone', phoneSave);
//                           await sharedPreferences.setString('apiDate', date);
//                           await sharedPreferences.setString('date', date);
//
//                          SystemChannels.platform.invokeMethod<void>('SystemNavigator.pop');
//                           // exit(0);
//                         }
//                         else(showSnakBar("مجددا تلاش کنید."));
//                       }
//                       catch(e){
//                         print(e.toString()+"خرجی از خستی");
//                         showSnakBar("مجددا تلاش کنید.");
//                       }
//
//                     } else
//                           () {};
                  },
                  title: Text(
                    'خروج از حساب',
                    style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.w400,
                        fontSize: 15 * fontvar),
                    textAlign: TextAlign.start,
                  ),
                  contentPadding:   EdgeInsets.all(0),
                  leading:   Padding(
                    padding:
                    EdgeInsets.only(
                        right: 15, top: 15,bottom: 15),
                    child:Icon(Icons.exit_to_app)
                  ) ,
                ),
//                 ListTile(
//                   onTap: () async {
//                     var databasesPath = await getDatabasesPath();
//                     String _path = Path.join(databasesPath, 'king.db');
//
//                     if (await databaseExists(_path)) {
// //      await ((await openDatabase(_path)).close());
//                       await deleteDatabase(_path);
//                       print("deleteDatabase");
//                     }
//                     try {
//                       await Directory(databasesPath).create(recursive: true);
//                     } catch (_) {}
//
//                     ByteData data = await rootBundle.load("assets/kingassets2.db");
//                     List<int> bytes = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
//                     await File(_path).writeAsBytes(bytes, flush: true);
//                   },
//                   title: Text(
//                     'خروج از حساب',
//                     style: TextStyle(
//                         color: textColor,
//                         fontWeight: FontWeight.w400,
//                         fontSize: 15 * fontvar),
//                     textAlign: TextAlign.start,
//                   ),
//                   contentPadding:   EdgeInsets.all(0),
//                   leading:   Padding(
//                     padding:
//                     EdgeInsets.only(
//                         right: 15, top: 15,bottom: 15),
//                     child:Icon(Icons.exit_to_app)
//                   ) ,
//                 ),



                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    GestureDetector(
                      child: Container(
                        margin: EdgeInsets.symmetric(horizontal: 5),
                        child: Image.network(
                          'assets/icons/instagram.svg', fit: BoxFit.fill,
                          width: 35 * (screenSize.width) / 375,
                          height: 35 * (screenSize.width) / 375,
                        ),
                      ),
                      onTap: () async {
                        await openApp(instagram);
                      },
                    ),
                    GestureDetector(
                      // child: Container(
                      //   margin: EdgeInsets.symmetric(horizontal: 5),
                      child: Image.asset(
                        'assets/images/wh.png',
                        width: 45 * (screenSize.width) / 375,
                        height: 45 * (screenSize.width) / 375,
                      ),
                      // ),
                      onTap: () async {
                        await openApp(rubika);
                      },
                    ),
                    GestureDetector(
                      child: Container(
                        margin: EdgeInsets.symmetric(horizontal: 5),
                        child: Image.network(
                          'assets/icons/telegram.svg', fit: BoxFit.fill,

                          width: 35 * (screenSize.width) / 375,
                          height: 35 * (screenSize.width) / 375,
                        ),
                      ),
                      onTap: () async {
                        await  openApp(telegram);
                      },
                    ),
                    GestureDetector(
                      child: Container(
                        margin: EdgeInsets.symmetric(horizontal: 5),
                        child: Image.network(
                          'assets/icons/site.svg',
                          fit: BoxFit.fill,
                          width: 35 * (screenSize.width) / 375,
                          height: 35 * (screenSize.width) / 375,
                        ),
                      ),
                      onTap: () async {
                        await   openApp(website);
                      },
                    ),

                  ],
                ),
                Padding(
                  padding: EdgeInsets.only(top:15),
                  child:Text(_version+ " نسخه",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Color(0xff818181),
                        fontSize:15*fontvar,
                        fontWeight: FontWeight.w500
                    ),) ,
                )
              ],
            ),
          )),
    );
  }



  // Future _getUser() async {
  //
  //   _user = await getUsersq();
  //   // PackageInfo packageInfo = await PackageInfo.fromPlatform();
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //
  //   if( prefs.getString("country")==null) {
  //
  //     print("dfdfdfdfdfdfdfdfdfdfdfd");
  //     await prefs.setString('country', _user.country);}
  //
  //   setState(() {
  //    if(_user!=null) _isLoading=false;
  //    // _version = packageInfo.version;
  //    _country=prefs.getString('country');
  //    _country=_country;
  //   });
  //   getEtebar();
  //
  //   return _user;
  // }

//   Future<User> getUsersq() async {
// //     User user;
// //     try {
// //       var db = new userProvider();
// //       await db.open();
// //       user = await db.paginate();
// // //      await db.close();
// //       return user;
// //     } catch (e) {
// //       print(e.toString() + "errrrrorrrrr");
// //       return null;
// //     }
//   }
//  Future<User> updateDb(User user) async {
//    try {
//      var db = new userProvider();
//      await db.open();
//      print(await db.update(user));
//      await db.close();
//      print("uppppppdat");
//    } catch (e) {
//      print(e.toString() + "errrrrorrrrr");
//      return null;
//    }
//
//  }


  void initTargets() {
    targets.add(TargetFocus(
      identify: "Target 1",
      keyTarget: keyButton1,
      contents: [
        ContentTarget(
            align: AlignContent.bottom,
            child: Container(
                child:
                Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: Text(
                    "با زدن هدف، می تونی تعیین کنی که میخوای چاق بشی یا لاغر، حتی می تونی مقدار و سرعت چاق یا لاغر شدنت رو هم مشخص کنی ما برات کالریتو تعیین می کنیم.",
                    style: TextStyle(color: Colors.white,
                        fontSize: 14 * fontvar,
                        fontWeight: FontWeight.w500),
                    textAlign: TextAlign.center,
                    textDirection: TextDirection.rtl,
                  ),
                )
            ))
      ],
      shape: ShapeLightFocus.RRect,

    ));
    targets.add(TargetFocus(
      identify: "Target 2",
      keyTarget: keyButton2,
      contents: [
        ContentTarget(
            align: AlignContent.top,
            child: Container(

              child: Padding(
                padding: EdgeInsets.only(top: 10.0),
                child: Text(
                  "این قسمت خیلی به درد بخوره هرچی غلات و مواد نشاسته ای هست رو به هم تبدیل می کنه، مثلا تو رژیمت نون لواش گذاشتن ولی میخوای نون سنگک بخوری، خیلی راحت اینجا می تونی مقدارشو تبدیل کنی.",
                  style: TextStyle(color: Colors.white,
                      fontSize: 14 * fontvar,
                      fontWeight: FontWeight.w500),
                  textAlign: TextAlign.center,
                  textDirection: TextDirection.rtl,
                ),

              ),
            ))
      ],
      shape: ShapeLightFocus.RRect,
    ));
  }

  void showTutorial() {
    TutorialCoachMark(context,
        targets: targets,
        colorShadow: MyColors.vazn,
        textSkip: "بستن",
        paddingFocus: 10,
        opacityShadow: 0.9,
     )
      ..show();
  }

  void _afterLayout(_) {
    Future.delayed(Duration(milliseconds: 400), () async {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String stringCoach = prefs.getString('coach');
      if (stringCoach != null) {
        List<String> arrayCoach = stringCoach.split("#");
        if (arrayCoach[1] == "0") {
          showTutorial();
          arrayCoach[1] = "1";
          String stringCoachSave = "";
          for (int i = 0; i < arrayCoach.length; i++) {
            if (i != 0)
              stringCoachSave = stringCoachSave + ("#");
            stringCoachSave = stringCoachSave + arrayCoach[i];
          }
          await prefs.setString('coach', stringCoachSave);
        }
      }
    });
  }

  showSnakBar(String name) {
    _scaffoldKey.currentState.showSnackBar(
        new SnackBar(
          duration: new Duration(seconds: 2),
          backgroundColor: MyColors.vazn,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(20))),

          content: Text(
            name,
            style: TextStyle(fontWeight: FontWeight.w400,
                fontSize: 15 * fontvar,
                fontFamily: "iransansDN"), textDirection: TextDirection.rtl,),
        ));
  }

   openApp(String url) async {
    if (await canLaunch(url)) {
      await launch(
        url,
        universalLinksOnly: true,
      );
    } else {
      throw 'There was a problem to open the url: $url';
    }
  }
//
//   deleteUser() async {
// //     try {
// //       var db = new userProvider();
// //       await db.open();
// //       await db.delete();
// // //      await db.close();
// //       print("deleteuser");
// //     } catch (e) {
// //       print(e.toString() + "errrrrorrrrr");
// //       return null;
// //     }
//
//   }
//   deleteDailyDiet() async {
// //     try {
// //       var db = new DailyDietProvider();
// //       await db.open();
// //       await db.delete();
// // //      await db.close();
// //       print("DailyDiet");
// //     } catch (e) {
// //       print(e.toString() + "errrrrorrrrr");
// //       return null;
// //     }
//
//   }
//
//
//
  setData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String contactus=prefs.getString("contactus");
    contact contactitem;
    if(contactus!=null){
      setState(() {
        contactitem= contact.fromJson(jsonDecode(contactus));
        website=contactitem.website;
        description=contactitem.description;
        telegram=contactitem.telegram;
        instagram=contactitem.instagram;
        rubika=contactitem.rubika;
      });
    }
   else if(await checkConnectionInternet())
      await getInfo();



  }
  Future<void> getInfo() async {

    SharedPreferences prefs = await SharedPreferences.getInstance();
    String apiToken=prefs.getString("user_token");


    final response = await Provider.of<apiServices>(context,listen: false).contactUs('Bearer '+apiToken);
    if (response.statusCode == 200) {
      final  post = json.decode(response.bodyString);
      print(post);
      contact contactitem;
      contactitem=(contact.fromJson(post));
      prefs.setString("contactus", jsonEncode(contactitem.toMap()));

      if(description==""){
        setState(() {
          website=contactitem.website;
          description=contactitem.description;
          telegram=contactitem.telegram;
          instagram=contactitem.instagram;
          rubika=contactitem.rubika;
        });
      }

    }
    else {
      print(response.statusCode.toString());
    }

  }
//
//   Future<void> getEtebar() async {
//
//
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//    String serverDate= prefs.getString("date")??getDateToday();
//    String acountDate=_user.account;
//
//    print("serverDate"+serverDate);
//     if(serverDate!=null && acountDate !=null  && acountDate !=""){
//       var persianDateee = PersianDateTime(jalaaliDateTime: acountDate);
//       var dateEtebarstr = persianDateee.toGregorian(format: 'YYYY-MM-DD');
//       DateTime datetoday = DateTime.parse(serverDate);
//       DateTime dateacount= DateTime.parse(dateEtebarstr);
//       print(dateacount
//           .difference(datetoday)
//           .inDays
//           .toString()+"fffffffffffffffffff");
//       etebar =dateacount.difference(datetoday).inDays;
//     }
//
//   }
}
