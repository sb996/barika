class DbAllDiets {

  int id;
  int day;
  String type;
  String Date;
  String user_id;
  String name;
  String advertice;
  String  ghol;
  String  me;
  String  extended_id;
  String alarm;

  DbAllDiets.fromJson(Map<String , dynamic> parsedJson) {


    id = parsedJson['id'];
    day = parsedJson['day']??1;
    type = parsedJson['type']??"";
    Date = parsedJson['Date']??"";
    user_id = parsedJson['user_id']??"";
    name = parsedJson['name']??"";
    advertice = parsedJson['advertice']??"";
    ghol = parsedJson['ghol']??"0";
    me = parsedJson['me']??"0";
    extended_id = parsedJson['extended_id'].toString();
    alarm = parsedJson['alarm'];


  }

  Map<String, dynamic> toMap() {

    return <String , dynamic>{
      'id' : id,
      'day' : day??"",
      'type':type??"",
      'Date':Date??"",
      'user_id' : user_id??"",
      'name' : name??"",
      'advertice' : advertice??"",
      'ghol' : ghol??"0",
      'me' : me??"0",
      'extended_id' : extended_id,
      'alarm' : alarm,

    };
  }
}