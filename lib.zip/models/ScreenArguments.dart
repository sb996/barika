
import 'package:barika_web/models/user.dart';

class ScreenArguments {
  String uid;
  User id;
  String type;
  String type2;
  String name;
  String metype;
  String dietId;
  int logId;

  ScreenArguments({this.uid, this.id,this.logId,this.metype,this.type,this.name,this.type2,this.dietId});
}