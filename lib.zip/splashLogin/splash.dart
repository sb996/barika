import 'dart:async';
import 'package:barika_web/models/user.dart';

import 'package:barika_web/utils/SizeConfig.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';


class SplashScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => new SplashScreenState();
}

class SplashScreenState extends State<SplashScreen> {


  User _user;
  startTime() {
    var _duration = new Duration(seconds: 3);
    return new Timer(_duration, checkLogin);
  }

  navigationLogin() {
    Navigator.of(context).pushReplacementNamed('/language');
  }

  navigationHome() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String get_info = prefs.getString('get_info');
    print('shared read ${get_info}');
    if (get_info == null)
      Navigator.of(context).pushReplacementNamed('/getInfo');
    else{
      _user=  await _getUser();
      (_user==null||_user.birthdate=="0")
          ? Navigator.of(context).pushReplacementNamed('/userInfo')
          : Navigator.of(context).pushReplacementNamed('/main');}
  }

  String _version="1.1.18 نسخه ";
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
//    getVesion();
    startTime();

    //s startTime();
  }
  Future<void> getVesion() async {

  }
  var loginColor = Color(0xffF15A23);
  var signupColor = Color(0xFF6DC07B);
  var textColor = Color(0xff51565F);
  var fontvar=1.0;
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    var bh=SizeConfig.safeBlockHorizontal;
    var bv=SizeConfig.safeBlockVertical;
    fontvar = (bh) / 3.75;
    if(fontvar>2)fontvar=1.7;

    Size screenSize = MediaQuery.of(context).size;
    // if(screenSize.width>600)screenSize=Size(600, screenSize.height);

    return new Scaffold(

        backgroundColor: signupColor,
        body:  Stack(
          alignment: AlignmentDirectional.center,

          children: <Widget>[


            Center(
                child:Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Expanded(
                      child:         Image.asset('assets/images/bg_intro.png',
                        color: Colors.transparent,
                        fit: BoxFit.contain,
                        alignment: Alignment.bottomCenter,
                        // height: screenSize.height / 3,
                      ),
                    ),
                    Image.asset('assets/images/logoorange.png',
                      fit: BoxFit.contain,
                      width: 109*(screenSize.width)/375,
                      height: 120*(screenSize.width)/375,),
                    Padding(
                        child:  Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text("دکتر مجید محمدشاهی",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize:15*fontvar,
                                  fontWeight: FontWeight.w500
                              ),),
                            Text("دکتر فاطمه حیدری",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize:15*fontvar,
                                  fontWeight: FontWeight.w500
                              ),),
                            Text("متخصصین تغذیه و رژیم درمانی",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize:15*fontvar,
                                  fontWeight: FontWeight.w400
                              ),),
                            Text("اساتید دانشگاه علوم پزشکی",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize:15*fontvar,
                                  fontWeight: FontWeight.w400
                              ),),

                          ],
                        ),
                        padding: EdgeInsets.only(bottom: 20,right: 15,left: 15,top:35)
                    ),
                    Expanded(
                      child:         Image.asset('assets/images/bg_intro.png',
                        color: Colors.white,
                        fit: BoxFit.fill,
                        alignment: Alignment.bottomCenter,
                        width: screenSize.width,
                      ),
                    )


                  ],
                )),
            // Align(
            //   child:      Padding(
            //     padding: EdgeInsets.only(top:15,bottom: 25),
            //     child:Text(_version,
            //       style: TextStyle(
            //           color:  Color(0xFF6DC07B),
            //           fontSize:15*fontvar,
            //           fontWeight: FontWeight.w600
            //       ),
            //       textDirection: TextDirection.ltr
            //       ,) ,
            //   ),
            //   alignment: Alignment.bottomCenter,
            // )

          ],
        ));
  }

  checkLogin() async {


    SharedPreferences prefs = await SharedPreferences.getInstance();
    // bool _seen = (prefs.getBool('seen') ?? false);
   prefs.setString('user_token',"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjhiM2I5NjE3ODJlNDlhMTMyMmM5YzA2M2ZiM2RkMzAwNTYwZDE4ZDk2M2Y4MTg4YzMxOTBhYTk5YTA3OTFlNjdjZGYzZWFiMTdiNmFmMmU3In0.eyJhdWQiOiIxIiwianRpIjoiOGIzYjk2MTc4MmU0OWExMzIyYzljMDYzZmIzZGQzMDA1NjBkMThkOTYzZjgxODhjMzE5MGFhOTlhMDc5MWU2N2NkZjNlYWIxN2I2YWYyZTciLCJpYXQiOjE2MDUwMDI1MzIsIm5iZiI6MTYwNTAwMjUzMiwiZXhwIjoxNjM2NTM4NTMyLCJzdWIiOiI5NjQ5Iiwic2NvcGVzIjpbXX0.AElo3pgdUh_jShl_i6E48VXXMOG3mQQngoV6Fa6fL1TCCM-IspahEGXCfM0AQp34cTbW6WqMxz7PUK8Ari4hs-_7Dl2xU59zG1VNNGCU2QDgVR57BNzE_gjNkYlc9SWCzMP1OCwuz6mvE1n_S_kPv4AUPRuZgRSBqemWg2nWqcliQsMGJAbEWltMWmMXwxZAgp82vQvu4ZAHweuZJmerCBii_QqWtTpkwFRltasmqlEdhsWf92MSN0AYPZHLMUNeC2FP-Xjk1JM-obZgL5KpCgI_KJDsyH660wgd8KtJomqvrF3EtdWBlftElKzWdfzphCWaDjwljCm6XxKUfsH_kzpS_QBl7XKxojBZ-kuwNz2amZkpTY5Pxady8-GMkCOnAmp2-pcui3IpsUTc42jwHmJt8rfk7GMN3QFsy9nK81VBYBrc4226hMk8LTdz8CppKbPk35WNXpEZgw4JgskZcUDaofsji7Lu1iqR2Xqg2XgUzuTKXEy2yL92hvwed21lR9X7zKiibBdXdj0KGc-3YWKkbUt8-FbFRRcIuFzk3vXjncvXE_hobRZm7SLf0iAdmGE5wh16oCSO5PHlh1B07Qx57YOBwtIL9yexOVeTB3mKCoV6fHgGvcZK9UsTfezNE4Z7m8awd2oUWqjVu5R0WDiKIqHbCiMvBEiXOdIExFs");
   // Navigator.pushReplacement(
   //   context,
   //   MaterialPageRoute(
   //     builder: (context) => Directionality(textDirection: TextDirection.rtl, child:getInfo()),
   //   ),
   // );
    Navigator.of(context).pushReplacementNamed('/main');

//     if (_seen) {
//       String apiToken = prefs.getString('user_token');
//       print('shared read ${apiToken}');
//       if (apiToken == null) {
//         navigationLogin();
//       }
//
// //      else if (await checkConnectionInternet()) {
// //        checkTokenFromServer(apiToken);
// //      }
//       else {
//         navigationHome();
//       }
//     }
//     else {
//       await prefs.setBool('seen', true);
//       Navigator.of(context).pushReplacement(
//           new MaterialPageRoute(builder: (context) => new IntroSlider()));
//     }
  }

//  Future<void> checkTokenFromServer(String apiToken) async {
//    try {
//      final response = await Provider.of<apiServices>(context, listen: false)
//          .getTokenActvation(
//          'Bearer ' + apiToken);
//      if (response.statusCode == 200) {
//        final post = json.decode(response.bodyString);
//        print(post.toString() + "post");
//        print(post["message"]);
//        if (post["message"] == "success")
//          navigationHome();
//        else
//          navigationLogin();
//      }
//      else
//        navigationHome();
//    }
//    catch (e) {
//      print (e.toString());
//      navigationHome();
//    }
//  }

  _getUser() async {
    var response = await getUser();

    if (this.mounted) {
      _user = response;

//      print(_user.toMap());

    }
    return _user;
  }

   Future<User> getUser()  {

    }
  }

